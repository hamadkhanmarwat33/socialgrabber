
const PLATFORMS=[
 {id:"youtube",name:"YouTube",hosts:["youtube.com","youtu.be","youtube-nocookie.com"],oembed:"https://www.youtube.com/oembed",status:"metadata",note:"Official oEmbed/Data API gives metadata only. No permitted API to download other users' videos. Own videos: download via YouTube Studio."},
 {id:"tiktok",name:"TikTok",hosts:["tiktok.com"],oembed:"https://www.tiktok.com/oembed",status:"metadata",note:"Official oEmbed for metadata/embed. Download only for authorized/own content via TikTok app/API permissions."},
 {id:"facebook",name:"Facebook",hosts:["facebook.com","fb.watch"],oembed:null,status:"authorized-only",note:"Meta Graph API requires app review + user token; only media you own/are authorized for."},
 {id:"instagram",name:"Instagram",hosts:["instagram.com"],oembed:null,status:"authorized-only",note:"Meta Graph API requires login + permissions; no public downloader API."},
 {id:"x",name:"X (Twitter)",hosts:["x.com","twitter.com"],oembed:"https://publish.twitter.com/oembed",status:"metadata",note:"oEmbed metadata only. Media download requires API access + rights."},
 {id:"vimeo",name:"Vimeo",hosts:["vimeo.com"],oembed:"https://vimeo.com/api/oembed.json",status:"supported-authorized",note:"oEmbed metadata free. Download files via Vimeo API only when video owner enabled it / it's your video + token."},
 {id:"dailymotion",name:"Dailymotion",hosts:["dailymotion.com","dai.ly"],oembed:"https://www.dailymotion.com/services/oembed",status:"metadata",note:"oEmbed metadata. File access per owner settings/API."},
 {id:"reddit",name:"Reddit",hosts:["reddit.com","redd.it"],oembed:"https://www.reddit.com/oembed",status:"metadata",note:"oEmbed metadata. Hosted video download not offered by official API for arbitrary posts."},
 {id:"pinterest",name:"Pinterest",hosts:["pinterest.com","pin.it"],oembed:null,status:"unsupported",note:"No free public video-download API."},
 {id:"twitch",name:"Twitch",hosts:["twitch.tv"],oembed:null,status:"metadata",note:"Helix API gives clip metadata with free Client-ID; VOD download not permitted via API."},
 {id:"linkedin",name:"LinkedIn",hosts:["linkedin.com"],oembed:null,status:"unsupported",note:"No public download API; requires member authorization."},
 {id:"snapchat",name:"Snapchat",hosts:["snapchat.com"],oembed:null,status:"unsupported",note:"No public download API."},
 {id:"threads",name:"Threads",hosts:["threads.net","threads.com"],oembed:null,status:"authorized-only",note:"Meta Threads API requires authorization for own content."},
 {id:"tumblr",name:"Tumblr",hosts:["tumblr.com"],oembed:"https://www.tumblr.com/oembed/1.0",status:"metadata",note:"oEmbed metadata where available."},
 {id:"rumble",name:"Rumble",hosts:["rumble.com"],oembed:"https://rumble.com/api/Media/oembed.json",status:"metadata",note:"oEmbed metadata where available."},
 {id:"likee",name:"Likee",hosts:["likee.video","l.likee.video"],oembed:null,status:"unsupported",note:"No official public download API found."},
 {id:"kwai",name:"Kwai",hosts:["kwai.com"],oembed:null,status:"unsupported",note:"No official public download API found."},
 {id:"direct",name:"Direct Media File",hosts:[],oembed:null,status:"supported",note:"Direct .mp4/.webm/.mp3 links you have rights to: full download supported."},
];
function detectPlatform(raw){
  let u; try{u=new URL(raw)}catch{return null}
  if(!["http:","https:"].includes(u.protocol)) return null;
  if(/\.(mp4|webm|mp3|m4a)(\?|#|$)/i.test(u.href)) return PLATFORMS.find(p=>p.id==="direct");
  const h=u.hostname.replace(/^www\.|^m\./,"");
  return PLATFORMS.find(p=>p.hosts.some(x=>h===x||h.endsWith("."+x)))||null;
}
if(typeof window!=='undefined')window.PLATFORMS=PLATFORMS;
